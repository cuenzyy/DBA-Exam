// function percentage_1() {

// 	// Method returns the element of percent id
// 	var percent = document.getElementById("percent").value;
	
// 	// Method returns the element of num id
// 	var num = document.getElementById("num").value;
// 	document.getElementById("value1")
// 		.value = (num / 100) * percent;
// }

// function percentage_2() {

// 	// Method returns the element of num1 id
// 	var num1 = document.getElementById("num1").value;
	
// 	// Method returns the elements of num2 id
// 	var num2 = document.getElementById("num2").value;
// 	document.getElementById("value2")
// 		.value = (num1 * 100) / num2 + "%";
// }


// newly hired function
function hiredFunc() {
        var newhm = document.getElementsByName("newhired_m")[0].value;
        var newhf = document.getElementsByName("newhired_f")[0].value;
        var calculatetotal = Number(newhm) + Number(newhf);
        var malepercentage = newhm / calculatetotal * 100;
        var femalepercentage = newhf / calculatetotal * 100;
        document.getElementsByName("calculatetotal")[0].value = calculatetotal;
        document.getElementsByName("malehiredpercentage")[0].value = malepercentage.toFixed(2)+"%";
        document.getElementsByName("femalehiredpercentage")[0].value = femalepercentage.toFixed(2)+"%";
    }

// permanent employees function
function permanentFunc() {
        var permanentM = document.getElementsByName("permanent_m")[0].value;
        var permanentF = document.getElementsByName("permanent_f")[0].value;
        var calculatepermanent = Number(permanentM) + Number(permanentF);
        var permanentmalepercentage = permanentM / calculatepermanent * 100;
        var permanentfemalepercentage = permanentF / calculatepermanent * 100;
        document.getElementsByName("calculatepermanentdisplay")[0].value = calculatepermanent;
        document.getElementsByName("malepermanentpercentage")[0].value = permanentmalepercentage.toFixed(2)+"%";
        document.getElementsByName("femalepermanentpercentage")[0].value = permanentfemalepercentage.toFixed(2)+"%";
    }

// resigned employees function
function resignedFunc() {
        var resignedM = document.getElementsByName("resigned_m")[0].value;
        var resignedF = document.getElementsByName("resigned_f")[0].value;
        var calculateresigned = Number(resignedM) + Number(resignedF);
        var resignedmalepercentage = resignedM / calculateresigned * 100;
        var resignedfemalepercentage = resignedF / calculateresigned * 100;
        document.getElementsByName("resignedtotaldisplay")[0].value = calculateresigned;
        document.getElementsByName("maleresignedpercentage")[0].value = resignedmalepercentage.toFixed(2)+"%";
        document.getElementsByName("femaleresignedpercentage")[0].value = resignedfemalepercentage.toFixed(2)+"%";
    }